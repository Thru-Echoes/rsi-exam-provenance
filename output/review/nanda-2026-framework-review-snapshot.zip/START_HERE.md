# Capture, Verify, Govern — review snapshot

Open paper.pdf first, then source/ara/nanda-2026/REVIEW.md.
This snapshot includes the four-page IEEE paper, ARA, study inputs and receipts.
It deliberately excludes Git history to keep the public review download small.
The original source instructions describe the separate full offline bundle.

Frozen source: ee8e2dce9f6ebd1b091ef962e32e1fe55f808e7d
Review only, not approval, submission or an anonymized artifact.

## Reproduce directly from this source snapshot

From source/:

```sh
python3 -m unittest tests.test_nanda_ara tests.test_conformance -q
python3 studies/handoff-case-review/review_cases.py --check
python3 ara/nanda-2026/src/execution/check_review_snapshot.py --check
```

These are structure, conformance, retained-case and saved-receipt checks. The
primary fault runner records Git HEAD and needs a real checkout; the historical
table check also needs pinned Git history. For both, obtain the complete offline
bundle from the author or clone the repository and select:

```sh
git clone https://github.com/Thru-Echoes/rsi-exam-provenance
cd rsi-exam-provenance
git checkout --detach ee8e2dce9f6ebd1b091ef962e32e1fe55f808e7d
python3 -m unittest tests.test_decision_audit tests.test_paper_results -q
```

Re-executing E07 additionally requires the pinned external Proofpress commit and
its dependency, documented in source/studies/framework-boundary/README.md. The
portable suite checks the saved E07 receipt, not external-code execution. No human
approval, downstream agent run or full-framework effectiveness is demonstrated.
